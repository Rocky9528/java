<template>
  <div>
    <h1>打印单据设定</h1>
  </div>
</template>

<script>
export default {
    data() {}
}
</script>

<style></style>
