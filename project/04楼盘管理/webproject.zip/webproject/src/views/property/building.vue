<template>
  <div>
    <batchAddGuide></batchAddGuide>
  </div>
</template>

<script>
import batchAddGuide from './batchAddGuide/StepForm'
export default {
  components: {
    batchAddGuide
  }
}
</script>
